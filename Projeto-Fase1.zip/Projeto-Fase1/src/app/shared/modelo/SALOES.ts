import {Salao} from './salao';

export const SALOES: Array<Salao> = [
  {
    nome: 'Salon 1',
    endereco: 'Rua xxx, numero tal',
    dono:'Robertin'},
  {
  nome: 'Salon 2',
    endereco: 'Rua zzz, numero do sono',
    dono:'Jão'},

]
